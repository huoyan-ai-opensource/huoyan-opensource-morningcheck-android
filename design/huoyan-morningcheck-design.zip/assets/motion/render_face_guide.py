from pathlib import Path
import math
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent.parent / 'review-20261014'
SCALE = 2
WIDTH, HEIGHT = 648, 420
COUNT, DURATION = 96, 50
BG = '#F2F4F8'
INK = '#4E608C'
PURPLE = '#4C42F5'
GREEN = '#27835B'
FONT = ImageFont.truetype('/System/Library/Fonts/STHeiti Medium.ttc', 27 * SCALE)
PERSON = Image.open(ROOT / 'g1tqVo.png').convert('RGBA')
DEVICE = Image.open(ROOT / 'X1zG1.png').convert('RGBA')


def smooth(x):
    x = max(0, min(1, x))
    return x * x * (3 - 2 * x)


def rgba(color, opacity=1):
    color = color.lstrip('#')
    return tuple(int(color[i:i + 2], 16) for i in (0, 2, 4)) + (round(255 * opacity),)


def walking_person(progress):
    """Match face-person.glsl in the original 160 × 300 illustration space."""
    if progress <= 0 or progress >= 1:
        return PERSON.copy()
    phase = progress * math.tau
    settle = math.sin(progress * math.pi)
    stride = math.sin(phase)
    bob = -1.4 * stride * stride * settle

    def source_at(x, y, leg):
        local_x, local_y = x / SCALE, y / SCALE
        sx, sy = local_x, local_y
        for _ in range(4):
            lower = smooth((sy - 198) / 76)
            lift = max(0, leg * math.cos(phase)) * 8 * settle
            sx = local_x - leg * 11 * stride * settle * lower
            sy = local_y - (bob * (1 - lower) - lift * lower)
        return sx * SCALE, sy * SCALE

    width, height = PERSON.size
    person = Image.new('RGBA', PERSON.size)
    for leg in [-1, 1]:
        layer = Image.new('RGBA', PERSON.size)
        for y in range(height):
            split = round((75 + 5 * smooth((y / SCALE - 198) / 72)) * SCALE)
            bounds = (0, y, split, y + 1) if leg < 0 else (split, y, width, y + 1)
            layer.paste(PERSON.crop(bounds), bounds[:2])
        mesh = []
        for y in range(0, height, 8):
            for x in range(0, width, 8):
                right, bottom = min(x + 8, width), min(y + 8, height)
                quad = (*source_at(x, y, leg), *source_at(x, bottom, leg),
                        *source_at(right, bottom, leg), *source_at(right, y, leg))
                mesh.append(((x, y, right, bottom), quad))
        person.alpha_composite(layer.transform(PERSON.size, Image.Transform.MESH, mesh,
                                               resample=Image.Resampling.BICUBIC))
    return person


def corners(draw, box, color, opacity, length=11):
    x0, y0, x1, y1 = [v * SCALE for v in box]
    d = length * SCALE
    for x, y, dx, dy in [(x0, y0, d, d), (x1, y0, -d, d),
                          (x0, y1, d, -d), (x1, y1, -d, -d)]:
        draw.line([(x + dx, y), (x, y), (x, y + dy)],
                  fill=rgba(color, opacity), width=3 * SCALE, joint='curve')


def frame_at(t):
    frame = Image.new('RGBA', (WIDTH * SCALE, HEIGHT * SCALE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(frame)
    draw.line([(168 * SCALE, 304 * SCALE), (487 * SCALE, 304 * SCALE)],
              fill='#DCE1ED', width=2 * SCALE)
    progress = smooth(t / 1.25)
    visibility = smooth(t / .2) * (1 - smooth((t - 4.35) / .45))
    x = 144 + 40 * progress
    person = walking_person(progress)
    person.putalpha(person.getchannel('A').point(lambda a: round(a * visibility)))
    frame.alpha_composite(person, (round(x * SCALE), 10 * SCALE))
    frame.alpha_composite(DEVICE, (336 * SCALE, 10 * SCALE))

    overlay = Image.new('RGBA', frame.size)
    d = ImageDraw.Draw(overlay)
    align = smooth((t - .9) / .65) * visibility
    gaze_y = 75
    eye_x, camera_x = x + 111, 426
    for start in range(round(eye_x + 12), camera_x - 13, 13):
        d.line([(start * SCALE, gaze_y * SCALE), ((start + 5) * SCALE, gaze_y * SCALE)],
               fill=rgba('#8C91CB', align * .8), width=2 * SCALE)
    pulse = (math.sin(t * math.pi * 2) + 1) / 2
    radius = 13 + 3 * pulse
    d.ellipse([(camera_x - radius) * SCALE, (gaze_y - radius) * SCALE,
               (camera_x + radius) * SCALE, (gaze_y + radius) * SCALE],
              outline=rgba(PURPLE, align * .55), width=2 * SCALE)
    hold = smooth((t - 3.25) / .35)
    color = GREEN if hold > .5 else PURPLE
    corners(d, (x + 44, 27, x + 119, 115), color, align, 12)
    corners(d, (398, 103, 454, 171), color, align, 8)
    if 1.55 <= t <= 3.4:
        scan_y = 107 + 58 * ((t - 1.55) / 1.85)
        for offset in range(-10, 1):
            alpha = (offset + 11) / 11 * .11
            d.line([(400 * SCALE, (scan_y + offset) * SCALE),
                    (452 * SCALE, (scan_y + offset) * SCALE)],
                   fill=rgba(PURPLE, alpha * align), width=SCALE)
        d.line([(400 * SCALE, scan_y * SCALE), (452 * SCALE, scan_y * SCALE)],
               fill=rgba(PURPLE, align * .9), width=2 * SCALE)
    frame.alpha_composite(overlay)

    draw = ImageDraw.Draw(frame)
    stage = 0 if t < 1.25 else 1 if t < 2.2 else 2
    captions = ['走近晨检设备', '脸部正对摄像头', '保持不动，等待识别']
    draw.text((WIDTH * SCALE / 2, 355 * SCALE), captions[stage],
              font=FONT, fill=INK, anchor='mm')
    for i in range(3):
        xx = (301 + i * 23) * SCALE
        draw.rounded_rectangle((xx, 386 * SCALE, xx + 12 * SCALE, 390 * SCALE),
                               radius=2 * SCALE,
                               fill=PURPLE if i == stage else '#D5D9E9')
    return frame.resize((WIDTH, HEIGHT), Image.Resampling.LANCZOS)


OUT.mkdir(parents=True, exist_ok=True)
frames = [frame_at(i * DURATION / 1000) for i in range(COUNT)]
palette_sheet = Image.new('RGB', (WIDTH * 4, HEIGHT))
for i, frame in enumerate([frames[10], frames[30], frames[50], frames[75]]):
    palette_sheet.paste(frame, (i * WIDTH, 0))
palette = palette_sheet.quantize(colors=255)
# Reserve index 255 for binary GIF transparency; disposal clears each previous frame.
palette.putpalette(palette.getpalette()[:765] + [0, 0, 0])
gif_frames = []
for frame in frames:
    indexed = frame.convert('RGB').quantize(palette=palette, dither=Image.Dither.NONE)
    indexed.paste(255, mask=frame.getchannel('A').point(lambda alpha: 255 if alpha < 128 else 0))
    gif_frames.append(indexed)
gif_frames[0].save(OUT / 'face-alignment-guide.gif', save_all=True,
                   append_images=gif_frames[1:], duration=DURATION, loop=0,
                   transparency=255, background=255, optimize=False, disposal=2)
base = Image.new('RGBA', (WIDTH * SCALE, HEIGHT * SCALE), (0, 0, 0, 0))
base_draw = ImageDraw.Draw(base)
base_draw.line([(168 * SCALE, 304 * SCALE), (487 * SCALE, 304 * SCALE)],
               fill='#DCE1ED', width=2 * SCALE)
base.alpha_composite(DEVICE, (336 * SCALE, 10 * SCALE))
base.resize((WIDTH, HEIGHT), Image.Resampling.LANCZOS).save(ROOT / 'face-guide-device.png')
frames[48].save(ROOT / 'face-guide-static.png')
storyboard = Image.new('RGB', (WIDTH * 3, HEIGHT), BG)
for i, index in enumerate([10, 32, 73]):
    storyboard.paste(frames[index], (i * WIDTH, 0))
storyboard.save(OUT / 'face-alignment-storyboard.png')
walk_storyboard = Image.new('RGB', (WIDTH * 4, HEIGHT), BG)
for i, index in enumerate([5, 10, 17, 25]):
    walk_storyboard.paste(frames[index], (i * WIDTH, 0))
walk_storyboard.save(OUT / 'walking-steps.png')
check = Image.open(OUT / 'face-alignment-guide.gif')
total_ms = 0
for i in range(check.n_frames):
    check.seek(i)
    total_ms += check.info['duration']
assert total_ms == COUNT * DURATION and check.info['loop'] == 0
print(f'Validated {check.n_frames} frames, {total_ms} ms loop')
